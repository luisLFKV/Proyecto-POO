package main.java.controlador;

public interface LoginListener {
    void onLoginSuccess();
    void onLoginFailure();
}
